"""Testes do gerador: invariantes da spec (banco-simulado.md) e reprodutibilidade.

Rodar da raiz do pacote: python -m pytest generator/tests -q
Usa escala reduzida (0.1) e 160 dias: ~1 s por execução, já passa do baseline de 100 dias (D-24).
"""

import gzip
import hashlib
from datetime import date

import numpy as np
import pytest

from generator import checks, output
from generator import config as cfg
from generator.core import Sink
from generator.normal import simulate_normal
from generator.scenarios import inject
from generator.world import br_holidays, build_world, ip_str, mfa_at, rand_ip

START, DAYS, SCALE = date(2026, 1, 1), 160, 0.1


def _run(seed):
    world = build_world(seed, START, DAYS, SCALE)
    sink = Sink(world, np.random.default_rng([seed, 21]))
    inject(world, sink, np.random.default_rng([seed, 31]), 1.0)
    simulate_normal(world, sink, np.random.default_rng([seed, 41]))
    return world, output.assemble(world, sink, 1, seed)


@pytest.fixture(scope="module")
def run42():
    return _run(42)


def _digest(data):
    h = hashlib.sha256()
    for a in (data.t, data.et, data.sid, data.rv, data.rs):
        h.update(np.ascontiguousarray(a).tobytes())
    return h.hexdigest()


# --- reprodutibilidade -------------------------------------------------------------------------
def test_mesma_semente_mesma_saida(run42):
    assert _digest(_run(42)[1]) == _digest(run42[1])


def test_sementes_diferentes_divergem(run42):
    assert _digest(_run(43)[1]) != _digest(run42[1])


# --- checagens da seção 9 ---------------------------------------------------------------------
def test_checagens_da_secao_9_passam(run42):
    resultados = checks.run(run42[1], full_scale=False)
    assert resultados, "nenhuma checagem executada"
    falhas = [nome for nome, ok, _ in resultados if not ok]
    assert not falhas, falhas


# --- invariantes dos eventos -----------------------------------------------------------------
def test_toda_sessao_tem_um_logout(run42):
    data = run42[1]
    n_logout = np.bincount(data.sid[data.et == 1], minlength=data.nS)
    assert (n_logout == 1).all()


def test_tempos_ordenados_por_sessao_e_tipos_validos(run42):
    data = run42[1]
    assert data.et.min() >= 0 and data.et.max() < len(cfg.ETYPES)
    assert len(data.t) == data.N == len(data.sid)


def test_cenarios_so_depois_do_baseline(run42):
    """D-24: nenhum cenário não-N começa antes de eval_start (recalculado sem usar checks.py)."""
    world, data = run42
    ep = np.asarray(data.s["ep"])
    t0 = np.asarray(data.s["t0"])
    familia = np.array([data.eps.family.values[e] if e >= 0 else "N" for e in ep])
    injetado = familia != "N"
    assert injetado.any(), "nenhum cenário injetado"
    dia = (t0 - np.datetime64(START, "s").astype(np.int64)) // 86400
    assert dia[injetado].min() >= world.eval_start - 1


def test_baseline_de_3_meses_em_escala_cheia():
    """Execução anual completa mantém a janela de baseline de D-24 (100 dias)."""
    assert build_world(1, START, 365, 0.05).eval_start == cfg.EVAL_START_DAY


def test_episodios_tem_familias_conhecidas(run42):
    assert set(run42[1].eps.family) <= {"P", "B", "L", "N"}


# --- saída em disco (D-17: rótulo nunca entra em corp) -----------------------------------------
def test_rotulo_nao_vaza_para_corp(run42, tmp_path):
    base = output.write(run42[1], str(tmp_path))
    corp = __import__("pathlib").Path(base) / "corp"
    proibidos = {"label", "episode_id", "is_malicious", "scenario_code", "family"}
    for f in corp.iterdir():
        op = gzip.open if f.suffix == ".gz" else open
        with op(f, "rt", encoding="utf-8") as fh:
            cabecalho = set(fh.readline().strip().split(","))
        assert not (cabecalho & proibidos), (f.name, cabecalho & proibidos)
    assert (__import__("pathlib").Path(base) / "ground_truth" / "episodes.csv").exists()


def test_catalogo_provisorio_marcado(run42, tmp_path):
    assert (run42[1].eps.shape[0]) > 0
    base = output.write(run42[1], str(tmp_path))
    texto = (
        __import__("pathlib").Path(base) / "ground_truth" / "episodes.csv"
    ).read_text(encoding="utf-8")
    assert "provisorio-v1" in texto


# --- mundo simulado --------------------------------------------------------------------------
def test_efetivo_proporcional_a_escala(run42):
    world = run42[0]
    assert len(world.emps) == pytest.approx(250 * SCALE, abs=3)


def test_feriados_incluem_carnaval_e_sexta_santa_2026():
    h = br_holidays(2026)
    assert date(2026, 1, 1) in h
    assert date(2026, 2, 17) in h  # terça de Carnaval (Páscoa 5/abr − 47 d)
    assert date(2026, 4, 3) in h  # Sexta-feira Santa
    assert date(2026, 6, 4) in h  # Corpus Christi


def test_ip_str_formato():
    assert ip_str(0x0A000001) == "10.0.0.1"
    assert ip_str(0xC6120001) == "198.18.0.1"


def test_rand_ip_dentro_da_faixa(run42):
    world = run42[0]
    rng = np.random.default_rng(0)
    for idx, faixa in enumerate(world.ranges):
        ip = rand_ip(world, rng, idx)
        assert faixa["base"] < ip < faixa["base"] + faixa["size"]


def test_mfa_desligado_nunca_ativo(run42):
    world = run42[0]
    sem_mfa = [e for e in world.emps if not e.mfa0]
    for e in sem_mfa[:5]:
        assert mfa_at(world, e, 0) is False


# --- config.py -----------------------------------------------------------------------------
def test_mix_proximo_de_um_e_normalizado_no_uso():
    """A linha `management` de config.MIX soma 0,995 (ASSUNÇÃO P15); normal.MIXN normaliza."""
    from generator.normal import MIXN

    for persona, linha in cfg.MIX.items():
        assert sum(linha) == pytest.approx(1.0, abs=0.01), persona
        assert sum(MIXN[persona]) == pytest.approx(1.0), persona


def test_personas_do_mix_e_das_coortes_coincidem():
    assert set(cfg.MIX) == set(cfg.PERSONAS) == {p for _, p, _, _ in cfg.COHORTS}


def test_coortes_somam_250_funcionarios():
    assert sum(n for *_, n in cfg.COHORTS) == 250


def test_faixas_de_volume_validas():
    for persona, p in cfg.PERSONAS.items():
        assert 0 < p["lo"] < p["hi"], persona


def test_probabilidades_de_dominio_somam_um():
    assert sum(cfg.DOMAIN_P) == pytest.approx(1.0)
    assert len(cfg.DOMAIN_P) == len(cfg.DOMAINS)


def test_parametros_de_mfa_sao_probabilidades():
    assert 0 <= cfg.MFA0_BASE <= cfg.MFA0_PRIV <= 1
    assert (
        cfg.PATCH_MEDIAN["it_infra"]
        < cfg.PATCH_MEDIAN["default"]
        < cfg.PATCH_MEDIAN["sales"]
    )


def test_dominios_sempre_example():
    assert all(d.endswith(".example") for d, _ in cfg.DOMAINS)
